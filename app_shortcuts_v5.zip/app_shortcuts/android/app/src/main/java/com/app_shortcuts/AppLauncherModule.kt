package com.app_shortcuts

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import com.facebook.react.bridge.*
import java.io.File

class AppLauncherModule(private val ctx: ReactApplicationContext) :
    ReactContextBaseJavaModule(ctx) {

    override fun getName() = "AppLauncher"

    private fun processTextIntent(text: String): Intent =
        Intent(Intent.ACTION_PROCESS_TEXT).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_PROCESS_TEXT, text)
            putExtra(Intent.EXTRA_PROCESS_TEXT_READONLY, true)
        }

    @ReactMethod
    fun getLaunchableApps(promise: Promise) {
        try {
            val pm = ctx.packageManager
            val popupPkgs = pm.queryIntentActivities(processTextIntent("x"), 0)
                .map { it.activityInfo.packageName }.toSet()
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val arr = Arguments.createArray()
            pm.queryIntentActivities(intent, 0)
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
                .forEach {
                    val m = Arguments.createMap()
                    m.putString("pkg", it.activityInfo.packageName)
                    m.putString("label", it.loadLabel(pm).toString())
                    m.putBoolean("popup", popupPkgs.contains(it.activityInfo.packageName))
                    arr.pushMap(m)
                }
            promise.resolve(arr)
        } catch (e: Exception) { promise.reject("ERR_LIST", e) }
    }

    @ReactMethod
    fun launch(pkg: String, text: String?) {
        val pm = ctx.packageManager
        if (!text.isNullOrEmpty()) {
            // 1) PROCESS_TEXT: plutajući prozor, kao "Translate" u Moon+ Readeru
            try {
                val pt = processTextIntent(text).apply { setPackage(pkg) }
                val ri = pm.queryIntentActivities(pt, 0).firstOrNull()
                if (ri != null) {
                    pt.setClassName(ri.activityInfo.packageName, ri.activityInfo.name)
                    pt.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    ctx.startActivity(pt)
                    return
                }
            } catch (e: Exception) {}
            // 2) SEND direktno toj aplikaciji
            try {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                    setPackage(pkg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (send.resolveActivity(pm) != null) { ctx.startActivity(send); return }
            } catch (e: Exception) {}
        }
        // 3) običan launch
        val i = pm.getLaunchIntentForPackage(pkg) ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    @ReactMethod
    fun exportIcon(pkg: String, destPath: String, promise: Promise) {
        try {
            val d: Drawable = ctx.packageManager.getApplicationIcon(pkg)
            val size = 96
            val bmp = if (d is BitmapDrawable && d.bitmap != null)
                Bitmap.createScaledBitmap(d.bitmap, size, size, true)
            else {
                val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
                val c = Canvas(b); d.setBounds(0, 0, size, size); d.draw(c); b
            }
            val f = File(destPath); f.parentFile?.mkdirs()
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            promise.resolve(destPath)
        } catch (e: Exception) { promise.reject("ERR_ICON", e) }
    }

    @ReactMethod
    fun readText(path: String, promise: Promise) {
        try {
            val f = File(path)
            promise.resolve(if (f.exists()) f.readText() else null)
        } catch (e: Exception) { promise.reject("ERR_READ", e) }
    }

    @ReactMethod(isBlockingSynchronousMethod = true)
    fun readTextSync(path: String): String? {
        return try {
            val f = File(path)
            if (f.exists()) f.readText() else null
        } catch (e: Exception) { null }
    }

    @ReactMethod
    fun writeText(path: String, text: String, promise: Promise) {
        try {
            val f = File(path); f.parentFile?.mkdirs(); f.writeText(text)
            promise.resolve(true)
        } catch (e: Exception) { promise.reject("ERR_WRITE", e) }
    }
}
