import React, { useCallback, useEffect, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { PluginManager } from 'sn-plugin-lib';
import { onSetupPress, setSlots, takePending } from './src/bridge';
import {
  InstalledApp, MAX_SHORTCUTS, Shortcut, exportIcon,
  listInstalledApps, loadShortcuts, registerSlots, saveShortcuts, pluginDirSync,
} from './src/shortcuts';

export default function App() {
  const [apps, setApps] = useState<InstalledApp[]>([]);
  const [selected, setSelected] = useState<string[]>([]);
  const [log, setLog] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);

  const refresh = useCallback(async () => {
    const list = await loadShortcuts();
    setSelected(list.map(s => s.pkg));
    setLog([]);
  }, []);

  useEffect(() => {
    (async () => {
      try { setApps(await listInstalledApps()); }
      catch (e: any) { setLog([`Lista aplikacija: ${e?.message ?? e}`]); }
      takePending();
      refresh();
    })();
    return onSetupPress(refresh);
  }, [refresh]);

  const toggle = (pkg: string) =>
    setSelected(cur =>
      cur.includes(pkg) ? cur.filter(p => p !== pkg)
        : cur.length < MAX_SHORTCUTS ? [...cur, pkg] : cur);

  const save = async () => {
    setBusy(true);
    const out: string[] = [];
    try {
      const list: Shortcut[] = [];
      for (const pkg of selected) {
        const label = apps.find(a => a.pkg === pkg)?.label ?? pkg;
        list.push({ pkg, label, icon: await exportIcon(pkg) });
      }
      await saveShortcuts(list);
      setSlots(list);
      out.push(`Sačuvano: ${list.length}`);
      out.push(`sync dir: ${pluginDirSync() ?? 'nema'}`);
      out.push(...(await registerSlots(list, true)));
      out.push('Ako dugmad nisu vidljiva: zatvori dokument i ponovo ga otvori.');
    } catch (e: any) {
      out.push(`Greška: ${e?.message ?? e}`);
    }
    setLog(out);
    setBusy(false);
  };

  return (
    <View style={s.container}>
      <Text style={s.title}>Izaberi aplikacije (max {MAX_SHORTCUTS})</Text>
      <FlatList
        data={apps}
        keyExtractor={a => a.pkg}
        renderItem={({ item }) => (
          <Pressable style={s.row} onPress={() => toggle(item.pkg)}>
            <Text style={s.check}>
              {selected.includes(item.pkg) ? `[${selected.indexOf(item.pkg) + 1}]` : '[ ]'}
            </Text>
            <Text style={s.label}>{item.label}{item.popup ? '  (popup)' : ''}</Text>
          </Pressable>
        )}
      />
      {log.length > 0 && (
        <View style={s.log}>
          {log.map((l, i) => <Text key={i} style={s.logText}>{l}</Text>)}
        </View>
      )}
      <View style={s.footer}>
        <Pressable style={s.btn} onPress={() => PluginManager.closePluginView()}>
          <Text style={s.btnText}>Zatvori</Text>
        </Pressable>
        <Pressable style={s.btn} onPress={save} disabled={busy}>
          <Text style={s.btnText}>{busy ? '...' : 'Sačuvaj'}</Text>
        </Pressable>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 24 },
  title: { fontSize: 26, fontWeight: '600', color: '#000', marginBottom: 12 },
  row: { flexDirection: 'row', paddingVertical: 14, borderBottomWidth: 1, borderColor: '#000' },
  check: { fontSize: 24, width: 64, color: '#000' },
  label: { fontSize: 24, color: '#000' },
  log: { borderTopWidth: 2, borderColor: '#000', paddingTop: 8, marginTop: 8 },
  logText: { fontSize: 16, color: '#000' },
  footer: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 16 },
  btn: { borderWidth: 2, borderColor: '#000', paddingVertical: 12, paddingHorizontal: 32 },
  btnText: { fontSize: 24, color: '#000' },
});
