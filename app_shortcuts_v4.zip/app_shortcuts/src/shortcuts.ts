import { NativeModules } from 'react-native';
import { PluginManager } from 'sn-plugin-lib';

const { AppLauncher } = NativeModules;

export const MAX_SHORTCUTS = 12;

export type Shortcut = { pkg: string; label: string };
export type InstalledApp = { pkg: string; label: string };

async function dir(): Promise<string> {
  const d = await PluginManager.getPluginDirPath();
  if (!d) throw new Error('Plugin dir not available');
  return d;
}

export async function loadShortcuts(): Promise<Shortcut[]> {
  try {
    const txt: string | null = await AppLauncher.readText(`${await dir()}/shortcuts.json`);
    return txt ? JSON.parse(txt) : [];
  } catch {
    return [];
  }
}

export async function saveShortcuts(list: Shortcut[]): Promise<void> {
  await AppLauncher.writeText(`${await dir()}/shortcuts.json`, JSON.stringify(list));
}

export async function listInstalledApps(): Promise<InstalledApp[]> {
  return AppLauncher.getLaunchableApps();
}

export function launchApp(pkg: string, text: string) {
  AppLauncher.launch(pkg, text);
}
