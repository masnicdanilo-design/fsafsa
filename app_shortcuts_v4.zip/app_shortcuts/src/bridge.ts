import { PluginManager, PluginDocAPI } from 'sn-plugin-lib';

export const SETUP_ID = 100;   // toolbar dugme: podešavanje
export const OPEN_ID = 300;    // selection meni: otvori u aplikaciji

export type Press = { id: number; text: string };

let pending: Press | null = null;
let subscriber: ((p: Press) => void) | null = null;

/** Poziva se iz index.js, odmah nakon registerButton. */
export function installBridge() {
  PluginManager.registerButtonListener({
    onButtonPress: async (event: any) => {
      let text = '';
      if (event?.id === OPEN_ID) {
        try {
          const r: any = await PluginDocAPI.getLastSelectedText();
          if (r?.success && r.result) text = r.result;
        } catch {}
      }
      const p: Press = { id: event?.id, text };
      if (subscriber) subscriber(p);
      else pending = p;
    },
  } as any);
}

export function takePending(): Press | null {
  const p = pending;
  pending = null;
  return p;
}

export function onPress(cb: (p: Press) => void) {
  subscriber = cb;
  return () => { if (subscriber === cb) subscriber = null; };
}
