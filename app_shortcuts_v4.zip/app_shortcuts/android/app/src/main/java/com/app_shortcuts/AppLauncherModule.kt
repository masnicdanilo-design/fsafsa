package com.app_shortcuts

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import com.facebook.react.bridge.*
import java.io.File

class AppLauncherModule(private val ctx: ReactApplicationContext) :
    ReactContextBaseJavaModule(ctx) {

    override fun getName() = "AppLauncher"

    @ReactMethod
    fun getLaunchableApps(promise: Promise) {
        try {
            val pm = ctx.packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val arr = Arguments.createArray()
            pm.queryIntentActivities(intent, 0)
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
                .forEach {
                    val m = Arguments.createMap()
                    m.putString("pkg", it.activityInfo.packageName)
                    m.putString("label", it.loadLabel(pm).toString())
                    arr.pushMap(m)
                }
            promise.resolve(arr)
        } catch (e: Exception) { promise.reject("ERR_LIST", e) }
    }

    @ReactMethod
    fun launch(pkg: String, text: String?) {
        val pm = ctx.packageManager
        // 1) Ako ima teksta, probaj "share" direktno ka toj aplikaciji
        if (!text.isNullOrEmpty()) {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
                setPackage(pkg)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (send.resolveActivity(pm) != null) {
                try { ctx.startActivity(send); return } catch (e: Exception) {}
            }
        }
        // 2) Inače običan launch aplikacije
        val i = pm.getLaunchIntentForPackage(pkg) ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    @ReactMethod
    fun exportIcon(pkg: String, destPath: String, promise: Promise) {
        try {
            val d: Drawable = ctx.packageManager.getApplicationIcon(pkg)
            val size = 96
            val bmp = if (d is BitmapDrawable && d.bitmap != null)
                Bitmap.createScaledBitmap(d.bitmap, size, size, true)
            else {
                val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
                val c = Canvas(b); d.setBounds(0, 0, size, size); d.draw(c); b
            }
            val f = File(destPath); f.parentFile?.mkdirs()
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            promise.resolve(destPath)
        } catch (e: Exception) { promise.reject("ERR_ICON", e) }
    }

    @ReactMethod
    fun readText(path: String, promise: Promise) {
        try {
            val f = File(path)
            promise.resolve(if (f.exists()) f.readText() else null)
        } catch (e: Exception) { promise.reject("ERR_READ", e) }
    }

    @ReactMethod
    fun writeText(path: String, text: String, promise: Promise) {
        try {
            val f = File(path); f.parentFile?.mkdirs(); f.writeText(text)
            promise.resolve(true)
        } catch (e: Exception) { promise.reject("ERR_WRITE", e) }
    }
}
