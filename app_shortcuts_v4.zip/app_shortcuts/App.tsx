import React, { useCallback, useEffect, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { PluginManager } from 'sn-plugin-lib';
import { onPress, takePending, Press, SETUP_ID } from './src/bridge';
import {
  InstalledApp, MAX_SHORTCUTS, Shortcut,
  launchApp, listInstalledApps, loadShortcuts, saveShortcuts,
} from './src/shortcuts';

type Mode = 'launch' | 'setup';

export default function App() {
  const [mode, setMode] = useState<Mode>('setup');
  const [text, setText] = useState('');
  const [shortcuts, setShortcuts] = useState<Shortcut[]>([]);
  const [apps, setApps] = useState<InstalledApp[]>([]);
  const [selected, setSelected] = useState<string[]>([]);
  const [msg, setMsg] = useState('');

  const handlePress = useCallback(async (p: Press) => {
    const list = await loadShortcuts();
    setShortcuts(list);
    setSelected(list.map(s => s.pkg));
    setText(p.text);
    setMsg('');
    setMode(p.id === SETUP_ID || list.length === 0 ? 'setup' : 'launch');
  }, []);

  useEffect(() => {
    (async () => {
      try { setApps(await listInstalledApps()); }
      catch (e: any) { setMsg(`Lista aplikacija: ${e?.message ?? e}`); }
      const p = takePending();
      if (p) handlePress(p);
      else {
        const list = await loadShortcuts();
        setShortcuts(list);
        setSelected(list.map(s => s.pkg));
      }
    })();
    return onPress(handlePress);
  }, [handlePress]);

  const close = () => PluginManager.closePluginView();

  const open = (s: Shortcut) => {
    launchApp(s.pkg, text);
    close();
  };

  const toggle = (pkg: string) =>
    setSelected(cur =>
      cur.includes(pkg) ? cur.filter(p => p !== pkg)
        : cur.length < MAX_SHORTCUTS ? [...cur, pkg] : cur);

  const save = async () => {
    try {
      const list: Shortcut[] = selected.map(pkg => ({
        pkg, label: apps.find(a => a.pkg === pkg)?.label ?? pkg,
      }));
      await saveShortcuts(list);
      setShortcuts(list);
      setMsg(`Sačuvano: ${list.length}`);
      if (text && list.length) setMode('launch');
    } catch (e: any) {
      setMsg(`Greška pri čuvanju: ${e?.message ?? e}`);
    }
  };

  if (mode === 'launch') {
    return (
      <View style={s.container}>
        <Text style={s.title}>Otvori u aplikaciji</Text>
        <Text style={s.preview} numberOfLines={3}>{text || '(nema selektovanog teksta)'}</Text>
        <FlatList
          data={shortcuts}
          keyExtractor={a => a.pkg}
          renderItem={({ item }) => (
            <Pressable style={s.bigBtn} onPress={() => open(item)}>
              <Text style={s.bigText}>{item.label}</Text>
            </Pressable>
          )}
        />
        <View style={s.footer}>
          <Pressable style={s.btn} onPress={() => setMode('setup')}>
            <Text style={s.btnText}>Uredi</Text>
          </Pressable>
          <Pressable style={s.btn} onPress={close}>
            <Text style={s.btnText}>Zatvori</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  return (
    <View style={s.container}>
      <Text style={s.title}>Izaberi aplikacije (max {MAX_SHORTCUTS})</Text>
      {!!msg && <Text style={s.msg}>{msg}</Text>}
      <FlatList
        data={apps}
        keyExtractor={a => a.pkg}
        renderItem={({ item }) => (
          <Pressable style={s.row} onPress={() => toggle(item.pkg)}>
            <Text style={s.check}>{selected.includes(item.pkg) ? '[x]' : '[ ]'}</Text>
            <Text style={s.label}>{item.label}</Text>
          </Pressable>
        )}
      />
      <View style={s.footer}>
        <Pressable style={s.btn} onPress={close}>
          <Text style={s.btnText}>Zatvori</Text>
        </Pressable>
        <Pressable style={s.btn} onPress={save}>
          <Text style={s.btnText}>Sačuvaj</Text>
        </Pressable>
      </View>
    </View>
  );
}

// E-ink: crno-bijelo, bez animacija
const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 24 },
  title: { fontSize: 26, fontWeight: '600', color: '#000', marginBottom: 12 },
  preview: { fontSize: 18, color: '#000', marginBottom: 16, borderWidth: 1, borderColor: '#000', padding: 8 },
  msg: { fontSize: 18, color: '#000', marginBottom: 8 },
  row: { flexDirection: 'row', paddingVertical: 14, borderBottomWidth: 1, borderColor: '#000' },
  check: { fontSize: 24, width: 56, color: '#000' },
  label: { fontSize: 24, color: '#000' },
  bigBtn: { borderWidth: 2, borderColor: '#000', paddingVertical: 20, paddingHorizontal: 16, marginBottom: 12 },
  bigText: { fontSize: 28, color: '#000' },
  footer: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 16 },
  btn: { borderWidth: 2, borderColor: '#000', paddingVertical: 12, paddingHorizontal: 32 },
  btnText: { fontSize: 24, color: '#000' },
});
