import { AppRegistry, Image } from 'react-native';
import App from './App';
import { name as appName } from './app.json';
import { PluginManager } from 'sn-plugin-lib';
import { installBridge, SETUP_ID, OPEN_ID } from './src/bridge';

AppRegistry.registerComponent(appName, () => App);
PluginManager.init();

// Sve se registruje ODMAH i sinhrono, kao u dokumentaciji.
const icon = Image.resolveAssetSource(require('./assets/icon.png')).uri;

// Toolbar (NOTE/DOC): podešavanje aplikacija
PluginManager.registerButton(1, ['NOTE', 'DOC'], {
  id: SETUP_ID,
  name: 'App shortcuts',
  icon,
  showType: 1,
});

// Context meni pri selekciji teksta u DOC readeru
PluginManager.registerButton(3, ['DOC'], {
  id: OPEN_ID,
  name: 'Open in app',
  icon,
  showType: 1,
});

installBridge();
