import { Image, NativeModules } from 'react-native';
import { PluginManager } from 'sn-plugin-lib';

const { AppLauncher } = NativeModules;

export const SETUP_BUTTON_ID = 100;
export const BASE_ID = 300; // dugmad 300..307 su shortcuti
export const MAX_SHORTCUTS = 8;

export type Shortcut = { pkg: string; label: string; icon: string };
export type InstalledApp = { pkg: string; label: string };

async function dir(): Promise<string> {
  const d = await PluginManager.getPluginDirPath();
  if (!d) throw new Error('Plugin dir not available');
  return d;
}

export async function loadShortcuts(): Promise<Shortcut[]> {
  try {
    const txt: string | null = await AppLauncher.readText(`${await dir()}/shortcuts.json`);
    return txt ? JSON.parse(txt) : [];
  } catch {
    return [];
  }
}

export async function saveShortcuts(list: Shortcut[]): Promise<void> {
  await AppLauncher.writeText(`${await dir()}/shortcuts.json`, JSON.stringify(list));
}

export async function listInstalledApps(): Promise<InstalledApp[]> {
  return AppLauncher.getLaunchableApps();
}

/** Izvuče ikonu aplikacije u PNG u plugin folder i vrati putanju. */
export async function exportIcon(pkg: string): Promise<string> {
  return AppLauncher.exportIcon(pkg, `${await dir()}/icons/${pkg}.png`);
}

export const TEST_ID = 399;

/** (Re)registruje shortcut dugmad u DOC context meniju. Vraća log za dijagnostiku. */
export async function registerShortcutButtons(list: Shortcut[]): Promise<string[]> {
  const log: string[] = [];
  const bundled = Image.resolveAssetSource(require('../assets/icon.png')).uri;
  for (let i = 0; i < MAX_SHORTCUTS; i++) {
    try { await PluginManager.unregisterButton(BASE_ID + i); } catch {}
  }
  try { await PluginManager.unregisterButton(TEST_ID); } catch {}

  // Probno dugme sa ikonom iz plugina (odvaja problem registracije od problema ikona)
  try {
    const ok = await PluginManager.registerButton(3, ['DOC'], {
      id: TEST_ID, name: 'TEST', icon: bundled, showType: 0,
    } as any);
    log.push(`TEST dugme: ${ok}`);
  } catch (e: any) {
    log.push(`TEST dugme GRESKA: ${e?.message ?? e}`);
  }

  for (let i = 0; i < Math.min(list.length, MAX_SHORTCUTS); i++) {
    const s = list[i];
    try {
      const ok = await PluginManager.registerButton(3, ['DOC'], {
        id: BASE_ID + i, name: s.label, icon: s.icon, showType: 0,
      } as any);
      log.push(`${s.label}: ${ok} (icon ${s.icon})`);
    } catch (e: any) {
      log.push(`${s.label} GRESKA: ${e?.message ?? e}`);
    }
  }
  return log;
}
